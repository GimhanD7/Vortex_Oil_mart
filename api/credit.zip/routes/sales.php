<?php
global $pdo, $inputData, $id, $method, $action;
$user = requireAuth(); // Require auth for sales
require_once __DIR__ . '/../credit.php';

$salesColumns = [
    'payment_method', 'status', 'customer_id', 'subtotal_amount', 'discount_rate',
    'discount_amount', 'tax_rate', 'tax_amount', 'business_date', 'cash_received',
    'cash_balance', 'sales_cycle_id', 'opening_cash_balance', 'original_sale_id', 'transaction_type'
];

function ensureSalesColumns() {
    global $pdo, $salesColumns;
    foreach ([
        "ALTER TABLE products ADD COLUMN product_type VARCHAR(30) NOT NULL DEFAULT 'packaged'",
        "ALTER TABLE products ADD COLUMN unit VARCHAR(20) NOT NULL DEFAULT 'Unit'",
        "ALTER TABLE products ADD COLUMN barrel_capacity_liters DECIMAL(10,3) NULL",
        "ALTER TABLE products MODIFY COLUMN stock_quantity DECIMAL(12,3) NOT NULL DEFAULT 0",
        "ALTER TABLE products MODIFY COLUMN reorder_level DECIMAL(12,3) NOT NULL DEFAULT 10",
        "ALTER TABLE sale_items MODIFY COLUMN quantity DECIMAL(12,3) NOT NULL",
        "ALTER TABLE inventory_movements MODIFY COLUMN quantity_change DECIMAL(12,3) NOT NULL",
        "ALTER TABLE inventory_movements MODIFY COLUMN stock_before DECIMAL(12,3) NOT NULL",
        "ALTER TABLE inventory_movements MODIFY COLUMN stock_after DECIMAL(12,3) NOT NULL",
    ] as $query) {
        try {
            $pdo->exec($query);
        } catch (PDOException $e) {
            // Existing databases may already match this shape
        }
    }
    
    // PHP/PDO version of adding missing columns (simplified check)
    // Normally migrations should be handled separately, but replicating Next.js logic here
    $stmt = $pdo->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sales'");
    $existingColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $alterQueries = [];
    if (!in_array('customer_id', $existingColumns)) $alterQueries[] = 'ADD COLUMN customer_id INT NULL';
    if (!in_array('payment_method', $existingColumns)) $alterQueries[] = "ADD COLUMN payment_method VARCHAR(40) NOT NULL DEFAULT 'Cash'";
    if (!in_array('status', $existingColumns)) $alterQueries[] = "ADD COLUMN status VARCHAR(30) NOT NULL DEFAULT 'completed'";
    if (!in_array('subtotal_amount', $existingColumns)) $alterQueries[] = 'ADD COLUMN subtotal_amount DECIMAL(10,2) NOT NULL DEFAULT 0';
    if (!in_array('discount_rate', $existingColumns)) $alterQueries[] = 'ADD COLUMN discount_rate DECIMAL(5,2) NOT NULL DEFAULT 0';
    if (!in_array('discount_amount', $existingColumns)) $alterQueries[] = 'ADD COLUMN discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0';
    if (!in_array('tax_rate', $existingColumns)) $alterQueries[] = 'ADD COLUMN tax_rate DECIMAL(5,2) NOT NULL DEFAULT 0';
    if (!in_array('tax_amount', $existingColumns)) $alterQueries[] = 'ADD COLUMN tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0';
    if (!in_array('business_date', $existingColumns)) {
        $pdo->exec('ALTER TABLE sales ADD COLUMN business_date DATE NULL');
        $pdo->exec('UPDATE sales SET business_date = DATE(created_at) WHERE business_date IS NULL');
    }
    if (!in_array('cash_received', $existingColumns)) $alterQueries[] = 'ADD COLUMN cash_received DECIMAL(10,2) NULL';
    if (!in_array('cash_balance', $existingColumns)) $alterQueries[] = 'ADD COLUMN cash_balance DECIMAL(10,2) NULL';
    if (!in_array('sales_cycle_id', $existingColumns)) $alterQueries[] = 'ADD COLUMN sales_cycle_id VARCHAR(60) NULL';
    if (!in_array('opening_cash_balance', $existingColumns)) $alterQueries[] = 'ADD COLUMN opening_cash_balance DECIMAL(10,2) NULL';
    if (!in_array('original_sale_id', $existingColumns)) $alterQueries[] = 'ADD COLUMN original_sale_id INT NULL';
    if (!in_array('transaction_type', $existingColumns)) $alterQueries[] = "ADD COLUMN transaction_type VARCHAR(20) NOT NULL DEFAULT 'sale'";
    
    if (count($alterQueries) > 0) {
        $pdo->exec('ALTER TABLE sales ' . implode(', ', $alterQueries));
    }
}

function ensureRevocationAuditTable() {
    global $pdo;
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS transaction_revocations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sale_id INT NULL,
            action_type VARCHAR(60) NOT NULL,
            cashier_id INT NOT NULL,
            approver_id INT NULL,
            reason VARCHAR(255) NOT NULL,
            affected_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            metadata TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_revocations_sale_id (sale_id),
            INDEX idx_revocations_cashier_id (cashier_id),
            INDEX idx_revocations_approver_id (approver_id),
            INDEX idx_revocations_created_at (created_at)
        )
    ");
}

function supervisorApproval() {
    global $pdo, $inputData;
    $username = $inputData['approver_username'] ?? '';
    $pin = isset($inputData['approver_pin']) ? $inputData['approver_pin'] : '';

    if (!is_string($username) || !is_string($pin) || trim($username) === '' || $pin === '' || strlen($username) > 255 || strlen($pin) > 1024) {
        sendJson(["error" => "Supervisor/admin approval is required"], 400);
    }

    $username = trim($username);
    enforceLoginRateLimit($username);
    $stmt = $pdo->prepare("SELECT id, username, password, role, employment_status FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $approver = $stmt->fetch();

    if (!$approver || $approver['role'] !== 'admin' || $approver['employment_status'] !== 'active' || !password_verify($pin, $approver['password'])) {
        sendJson(["error" => "Invalid supervisor/admin PIN"], 403);
    }

    return $approver;
}

function recordRevocation($saleId, $actionType, $cashierId, $approverId, $reason, $affectedAmount, $metadata = []) {
    global $pdo;

    $stmt = $pdo->prepare("
        INSERT INTO transaction_revocations
        (sale_id, action_type, cashier_id, approver_id, reason, affected_amount, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $saleId,
        $actionType,
        $cashierId,
        $approverId,
        $reason,
        $affectedAmount,
        json_encode($metadata)
    ]);

    return $pdo->lastInsertId();
}

function saleItems($saleId) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT
            si.product_id,
            si.quantity,
            si.price_at_time,
            COALESCE(p.name, CONCAT('Product #', si.product_id)) AS product_name,
            p.sku
            ,p.unit
            ,p.product_type
        FROM sale_items si
        LEFT JOIN products p ON p.id = si.product_id
        WHERE si.sale_id = ?
        ORDER BY si.id ASC
    ");
    $stmt->execute([$saleId]);
    return $stmt->fetchAll();
}

function ensureSalesTableColumn($table, $column, $definition) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
        $stmt->execute([$table, $column]);
        if ((int)$stmt->fetchColumn() === 0) {
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN $definition");
        }
    } catch (Exception $e) {}
}

function ensureSalesCyclesTable() {
    global $pdo;
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sales_cycles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            cycle_id VARCHAR(60) NOT NULL UNIQUE,
            cashier_id INT NOT NULL,
            opened_at DATETIME NOT NULL,
            opened_date DATE NOT NULL,
            opening_balance DECIMAL(10,2) NOT NULL DEFAULT 0,
            closing_balance DECIMAL(10,2) NULL,
            closed_at DATETIME NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_sales_cycle_cashier (cashier_id),
            INDEX idx_sales_cycle_status (status)
        )
    ");

    ensureSalesTableColumn('sales_cycles', 'opened_date', '`opened_date` DATE NULL');
    ensureSalesTableColumn('sales_cycles', 'opening_balance', '`opening_balance` DECIMAL(10,2) NOT NULL DEFAULT 0');
    ensureSalesTableColumn('sales_cycles', 'closing_balance', '`closing_balance` DECIMAL(10,2) NULL');
    ensureSalesTableColumn('sales_cycles', 'closed_at', '`closed_at` DATETIME NULL');
    ensureSalesTableColumn('sales_cycles', 'updated_at', '`updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');

    try {
        $pdo->exec("UPDATE sales_cycles SET opened_date = DATE(opened_at) WHERE opened_date IS NULL AND opened_at IS NOT NULL");
    } catch (Exception $e) {}

    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sales_cycles' AND COLUMN_NAME = 'opening_cash'");
        if ((int)$stmt->fetchColumn() > 0) {
            $pdo->exec("UPDATE sales_cycles SET opening_balance = opening_cash WHERE (opening_balance = 0 OR opening_balance IS NULL) AND opening_cash IS NOT NULL");
        }
    } catch (Exception $e) {}

    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sales_cycles' AND COLUMN_NAME = 'closing_cash'");
        if ((int)$stmt->fetchColumn() > 0) {
            $pdo->exec("UPDATE sales_cycles SET closing_balance = closing_cash WHERE closing_balance IS NULL AND closing_cash IS NOT NULL");
        }
    } catch (Exception $e) {}
}

function ensureSaleReturnTables() {
    global $pdo;
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sale_returns (
            id INT AUTO_INCREMENT PRIMARY KEY,
            original_sale_id INT NOT NULL,
            return_number VARCHAR(40) NULL,
            transaction_type VARCHAR(20) NOT NULL DEFAULT 'return',
            resolution VARCHAR(30) NOT NULL DEFAULT 'Cash',
            refund_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            reason VARCHAR(255) NOT NULL,
            notes TEXT NULL,
            replacement_sale_id INT NULL,
            cashier_id INT NOT NULL,
            sales_cycle_id VARCHAR(60) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_sale_returns_original (original_sale_id),
            INDEX idx_sale_returns_replacement (replacement_sale_id),
            INDEX idx_sale_returns_cycle (sales_cycle_id),
            INDEX idx_sale_returns_created (created_at)
        )
    ");

    ensureSalesTableColumn('sale_returns', 'return_number', '`return_number` VARCHAR(40) NULL');
    ensureSalesTableColumn('sale_returns', 'transaction_type', "`transaction_type` VARCHAR(20) NOT NULL DEFAULT 'return'");
    ensureSalesTableColumn('sale_returns', 'resolution', "`resolution` VARCHAR(30) NOT NULL DEFAULT 'Cash'");
    ensureSalesTableColumn('sale_returns', 'refund_amount', '`refund_amount` DECIMAL(10,2) NOT NULL DEFAULT 0');
    ensureSalesTableColumn('sale_returns', 'reason', "`reason` VARCHAR(255) NULL");
    ensureSalesTableColumn('sale_returns', 'notes', '`notes` TEXT NULL');
    ensureSalesTableColumn('sale_returns', 'replacement_sale_id', '`replacement_sale_id` INT NULL');
    ensureSalesTableColumn('sale_returns', 'sales_cycle_id', '`sales_cycle_id` VARCHAR(60) NULL');
    ensureSalesTableColumn('sale_returns', 'status', "`status` VARCHAR(20) NOT NULL DEFAULT 'completed'");

    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sale_returns' AND COLUMN_NAME = 'resolution_type'");
        if ((int)$stmt->fetchColumn() > 0) {
            $pdo->exec("UPDATE sale_returns SET resolution = resolution_type WHERE resolution IS NULL OR resolution = 'Cash'");
        }
    } catch (Exception $e) {}

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sale_return_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            return_id INT NOT NULL,
            sale_item_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity DECIMAL(12,3) NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            line_refund DECIMAL(10,2) NOT NULL,
            disposition VARCHAR(30) NOT NULL DEFAULT 'resellable',
            INDEX idx_return_items_return (return_id),
            INDEX idx_return_items_sale_item (sale_item_id)
        )
    ");

    ensureSalesTableColumn('sale_return_items', 'line_refund', '`line_refund` DECIMAL(10,2) NOT NULL DEFAULT 0');
    ensureSalesTableColumn('sale_return_items', 'disposition', "`disposition` VARCHAR(30) NOT NULL DEFAULT 'resellable'");

    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sale_return_items' AND COLUMN_NAME = 'line_total'");
        if ((int)$stmt->fetchColumn() > 0) {
            $pdo->exec("UPDATE sale_return_items SET line_refund = line_total WHERE (line_refund = 0 OR line_refund IS NULL) AND line_total > 0");
        }
    } catch (Exception $e) {}
}

function detailedSaleItems($saleId) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT si.id AS sale_item_id, si.product_id, si.quantity, si.price_at_time,
               COALESCE(p.name, CONCAT('Product #', si.product_id)) AS product_name,
               p.sku, p.unit, p.product_type,
               COALESCE((SELECT SUM(sri.quantity) FROM sale_return_items sri
                         JOIN sale_returns sr ON sr.id = sri.return_id
                         WHERE sri.sale_item_id = si.id AND sr.status = 'completed'), 0) AS returned_quantity
        FROM sale_items si
        LEFT JOIN products p ON p.id = si.product_id
        WHERE si.sale_id = ? ORDER BY si.id
    ");
    $stmt->execute([$saleId]);
    return $stmt->fetchAll();
}

if ($method === 'POST' && $id === 'revocations') {
    try {
        ensureSalesColumns();
        ensureRevocationAuditTable();
        ensureCreditAccountTables();

        $actionType = isset($inputData['action_type']) ? trim($inputData['action_type']) : '';
        $reason = isset($inputData['reason']) ? trim($inputData['reason']) : '';
        $affectedAmount = isset($inputData['affected_amount']) ? (float)$inputData['affected_amount'] : 0;
        $metadata = isset($inputData['metadata']) && is_array($inputData['metadata']) ? $inputData['metadata'] : [];
        $saleId = isset($inputData['sale_id']) && $inputData['sale_id'] !== null ? (int)$inputData['sale_id'] : null;
        $approvalRequired = in_array($actionType, ['completed_sale_voided', 'refund_return_cancelled']);
        $approver = $approvalRequired ? supervisorApproval() : null;

        if ($actionType === '' || $reason === '') {
            sendJson(["error" => "Revocation type and reason are required"], 400);
        }

        $auditId = recordRevocation(
            $saleId,
            $actionType,
            $user['id'],
            $approver ? $approver['id'] : null,
            $reason,
            $affectedAmount,
            $metadata
        );

        sendJson(["message" => "Revocation recorded", "audit_id" => $auditId], 201);
    } catch (PDOException $e) {
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($method === 'GET' && $id === 'revocations') {
    try {
        ensureSalesColumns();
        ensureRevocationAuditTable();

        $stmt = $pdo->prepare("
            SELECT
                tr.id,
                tr.sale_id,
                tr.action_type,
                tr.reason,
                tr.affected_amount,
                tr.metadata,
                tr.created_at,
                cashier.username AS cashier_name,
                approver.username AS approver_name,
                s.status AS sale_status,
                s.payment_method,
                s.total_amount,
                s.created_at AS sale_created_at,
                c.name AS customer_name
            FROM transaction_revocations tr
            LEFT JOIN users cashier ON cashier.id = tr.cashier_id
            LEFT JOIN users approver ON approver.id = tr.approver_id
            LEFT JOIN sales s ON s.id = tr.sale_id
            LEFT JOIN customers c ON c.id = s.customer_id
            ORDER BY tr.created_at DESC, tr.id DESC
            LIMIT 300
        ");
        $stmt->execute();
        sendJson($stmt->fetchAll());
    } catch (PDOException $e) {
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($method === 'GET' && $id === 'returns') {
    ensureSaleReturnTables();
    $stmt = $pdo->query("
        SELECT sr.*, s.payment_method AS original_payment_method, s.total_amount AS original_total,
               s.status AS original_status, c.name AS customer_name, u.username AS cashier_name,
               COUNT(sri.id) AS line_count, COALESCE(SUM(sri.quantity), 0) AS item_quantity
        FROM sale_returns sr
        JOIN sales s ON s.id = sr.original_sale_id
        LEFT JOIN customers c ON c.id = s.customer_id
        LEFT JOIN users u ON u.id = sr.cashier_id
        LEFT JOIN sale_return_items sri ON sri.return_id = sr.id
        GROUP BY sr.id, s.payment_method, s.total_amount, s.status, c.name, u.username
        ORDER BY sr.id DESC LIMIT 500
    ");
    sendJson($stmt->fetchAll());
}

if ($method === 'GET' && is_numeric($id)) {
    try {
        ensureSalesColumns();
        ensureSaleReturnTables();

        $stmt = $pdo->prepare("
            SELECT s.id, s.subtotal_amount, s.discount_rate, s.discount_amount,
                   s.tax_rate, s.tax_amount, s.business_date, s.cash_received, s.cash_balance,
                   s.sales_cycle_id, s.opening_cash_balance, s.total_amount, s.payment_method,
                   s.status, s.created_at,
                   u.username as cashier_name, c.name as customer_name
            FROM sales s
            LEFT JOIN users u ON s.cashier_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE s.id = ?
        ");
        $stmt->execute([(int)$id]);
        $sale = $stmt->fetch();

        if (!$sale) {
            sendJson(["error" => "Sale not found"], 404);
        }

        $items = detailedSaleItems((int)$id);

        sendJson([
            "sale" => $sale,
            "items" => $items
        ]);
    } catch (PDOException $e) {
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($method === 'POST' && is_numeric($id) && $action === 'returns') {
    try {
        ensureSalesColumns();
        ensureRevocationAuditTable();
        ensureCreditAccountTables();
        ensureSaleReturnTables();
        $reason = trim((string)($inputData['reason'] ?? ''));
        $notes = trim((string)($inputData['notes'] ?? ''));
        $resolution = trim((string)($inputData['resolution'] ?? 'Cash'));
        $transactionType = $resolution === 'Exchange' ? 'exchange' : 'return';
        $requestedItems = is_array($inputData['items'] ?? null) ? $inputData['items'] : [];
        $allowedResolutions = ['Cash', 'Card', 'Bank Transfer', 'Credit Adjustment', 'Exchange'];
        if ($reason === '' || !$requestedItems || !in_array($resolution, $allowedResolutions, true)) {
            sendJson(['error' => 'Return items, resolution and reason are required'], 400);
        }

        $pdo->beginTransaction();
        $stmt = $pdo->prepare('SELECT * FROM sales WHERE id = ? FOR UPDATE');
        $stmt->execute([(int)$id]);
        $sale = $stmt->fetch();
        if (!$sale || in_array($sale['status'], ['cancelled', 'voided'], true)) {
            throw new Exception('Only an active completed invoice can be returned');
        }

        // Check if invoice is from a past date
        $today = date('Y-m-d');
        $invoiceDate = substr($sale['business_date'] ?: $sale['created_at'], 0, 10);
        if ($invoiceDate !== $today && $user['role'] !== 'admin') {
            $adminUser = $inputData['admin_username'] ?? '';
            $adminPass = $inputData['admin_password'] ?? '';
            if (empty($adminUser) || empty($adminPass)) {
                throw new Exception('Admin credentials required to return past-date invoices.');
            }
            $stmtAdmin = $pdo->prepare('SELECT password, role FROM users WHERE username = ? LIMIT 1');
            $stmtAdmin->execute([$adminUser]);
            $adminRow = $stmtAdmin->fetch();
            if (!$adminRow || $adminRow['role'] !== 'admin' || !password_verify($adminPass, $adminRow['password'])) {
                throw new Exception('Invalid admin credentials.');
            }
        }
        $availableItems = [];
        foreach (detailedSaleItems((int)$id) as $row) $availableItems[(int)$row['sale_item_id']] = $row;
        $discountFactor = max(0, 1 - ((float)$sale['discount_rate'] / 100));
        $prepared = [];
        $refundAmount = 0;
        foreach ($requestedItems as $requested) {
            $saleItemId = (int)($requested['sale_item_id'] ?? 0);
            $quantity = (float)($requested['quantity'] ?? 0);
            $disposition = ($requested['disposition'] ?? 'resellable') === 'damaged' ? 'damaged' : 'resellable';
            if (!isset($availableItems[$saleItemId]) || $quantity <= 0) throw new Exception('Invalid return item or quantity');
            $source = $availableItems[$saleItemId];
            $remaining = (float)$source['quantity'] - (float)$source['returned_quantity'];
            if ($quantity > $remaining + 0.0001) throw new Exception('Return quantity exceeds the quantity available on the original invoice');
            $lineRefund = round($quantity * (float)$source['price_at_time'] * $discountFactor, 2);
            $refundAmount += $lineRefund;
            $prepared[] = [$source, $quantity, $disposition, $lineRefund];
        }

        $stmt = $pdo->prepare("INSERT INTO sale_returns
            (original_sale_id, transaction_type, resolution, refund_amount, reason, notes, cashier_id, sales_cycle_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([(int)$id, $transactionType, $resolution, $refundAmount, $reason, $notes ?: null, $user['id'], $inputData['sales_cycle_id'] ?? $sale['sales_cycle_id']]);
        $returnId = (int)$pdo->lastInsertId();
        $returnNumber = 'RTN-' . str_pad((string)$returnId, 6, '0', STR_PAD_LEFT);
        $pdo->prepare('UPDATE sale_returns SET return_number = ? WHERE id = ?')->execute([$returnNumber, $returnId]);

        foreach ($prepared as [$source, $quantity, $disposition, $lineRefund]) {
            $pdo->prepare("INSERT INTO sale_return_items
                (return_id, sale_item_id, product_id, quantity, unit_price, line_refund, disposition)
                VALUES (?, ?, ?, ?, ?, ?, ?)")->execute([$returnId, $source['sale_item_id'], $source['product_id'], $quantity, $source['price_at_time'], $lineRefund, $disposition]);
            if ($disposition === 'resellable') {
                $stockStmt = $pdo->prepare('SELECT stock_quantity FROM products WHERE id = ? FOR UPDATE');
                $stockStmt->execute([$source['product_id']]);
                $before = (float)$stockStmt->fetchColumn();
                $after = $before + $quantity;
                $pdo->prepare('UPDATE products SET stock_quantity = ? WHERE id = ?')->execute([$after, $source['product_id']]);
                $pdo->prepare("INSERT INTO inventory_movements
                    (product_id, movement_type, quantity_change, stock_before, stock_after, unit_price, reference_no, notes, created_by)
                    VALUES (?, 'return', ?, ?, ?, ?, ?, 'Customer return - resellable stock', ?)")
                    ->execute([$source['product_id'], $quantity, $before, $after, $source['price_at_time'], $returnNumber, $user['id']]);
            }
        }

        if (!empty($sale['customer_id'])) {
            $pdo->prepare('UPDATE customers SET total_purchases = GREATEST(0, total_purchases - ?) WHERE id = ?')->execute([$refundAmount, $sale['customer_id']]);
            if ($sale['payment_method'] === 'Credit' || $resolution === 'Credit Adjustment') {
                $customerStmt = $pdo->prepare('SELECT outstanding_balance FROM customers WHERE id = ? FOR UPDATE');
                $customerStmt->execute([$sale['customer_id']]);
                $balance = (float)$customerStmt->fetchColumn();
                $applied = min($balance, $refundAmount);
                $next = max(0, $balance - $applied);
                $pdo->prepare('UPDATE customers SET outstanding_balance = ? WHERE id = ?')->execute([$next, $sale['customer_id']]);
                if ($applied > 0) addCreditLedgerEntry($sale['customer_id'], 'sale_return', 0, $applied, $next, (int)$id, null, $returnNumber, 'Return credited to customer account', $user['id']);
            }
        }

        $remainingCountStmt = $pdo->prepare("SELECT COUNT(*) FROM sale_items si WHERE si.sale_id = ? AND si.quantity > COALESCE((SELECT SUM(sri.quantity) FROM sale_return_items sri JOIN sale_returns sr ON sr.id=sri.return_id WHERE sri.sale_item_id=si.id AND sr.status='completed'),0)");
        $remainingCountStmt->execute([(int)$id]);
        $nextStatus = (int)$remainingCountStmt->fetchColumn() === 0 ? 'returned' : 'partially_returned';
        $pdo->prepare('UPDATE sales SET status = ? WHERE id = ?')->execute([$nextStatus, (int)$id]);
        recordRevocation((int)$id, $transactionType === 'exchange' ? 'sale_exchange' : 'sale_return', $user['id'], null, $reason, $refundAmount, ['return_id' => $returnId, 'return_number' => $returnNumber, 'resolution' => $resolution]);
        $pdo->commit();
        sendJson(['message' => 'Return recorded', 'return_id' => $returnId, 'return_number' => $returnNumber, 'refund_amount' => $refundAmount, 'status' => $nextStatus], 201);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        sendJson(['error' => $e->getMessage()], 400);
    }
}

if ($method === 'GET' && !$id) {
    try {
        ensureSalesColumns();
        ensureSaleReturnTables();
        
        $dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : null;
        $dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : null;
        $cashier = isset($_GET['cashier']) ? $_GET['cashier'] : null;
        $paymentMethod = isset($_GET['payment_method']) ? $_GET['payment_method'] : null;
        $status = isset($_GET['status']) ? $_GET['status'] : null;
        $cycleId = isset($_GET['cycle_id']) ? $_GET['cycle_id'] : null;
        
        $invoiceId = isset($_GET['invoice_id']) ? $_GET['invoice_id'] : null;
        $customerName = isset($_GET['customer_name']) ? $_GET['customer_name'] : null;
        $customerPhone = isset($_GET['customer_phone']) ? $_GET['customer_phone'] : null;
        $searchQuery = isset($_GET['search']) ? $_GET['search'] : null;

        $where = [];
        $values = [];

        if ($dateFrom) {
            $where[] = 'COALESCE(s.business_date, DATE(s.created_at)) >= ?';
            $values[] = $dateFrom;
        }
        if ($dateTo) {
            $where[] = 'COALESCE(s.business_date, DATE(s.created_at)) <= ?';
            $values[] = $dateTo;
        }
        if ($cashier && $cashier !== 'All Cashiers') {
            $where[] = 'u.username = ?';
            $values[] = $cashier;
        }
        if ($paymentMethod && $paymentMethod !== 'All Payment Methods') {
            $where[] = 's.payment_method = ?';
            $values[] = $paymentMethod;
        }
        if ($status && $status !== 'All Status') {
            $where[] = 's.status = ?';
            $values[] = strtolower($status);
        }
        if ($cycleId) {
            $where[] = 's.sales_cycle_id = ?';
            $values[] = $cycleId;
        }
        if ($invoiceId) {
            $where[] = 's.id = ?';
            $values[] = (int)str_replace('INV-', '', $invoiceId);
        }
        if ($customerName) {
            $where[] = 'c.name LIKE ?';
            $values[] = '%' . $customerName . '%';
        }
        if ($customerPhone) {
            $where[] = 'c.phone LIKE ?';
            $values[] = '%' . $customerPhone . '%';
        }
        if ($searchQuery) {
            $cleanInv = (int)preg_replace('/[^0-9]/', '', $searchQuery);
            $searchTerm = '%' . $searchQuery . '%';
            $where[] = '(s.id = ? OR CAST(s.id AS CHAR) LIKE ? OR c.name LIKE ? OR c.phone LIKE ? OR si.product_id IN (SELECT id FROM products WHERE name LIKE ? OR sku LIKE ?))';
            $values[] = $cleanInv;
            $values[] = $searchTerm;
            $values[] = $searchTerm;
            $values[] = $searchTerm;
            $values[] = $searchTerm;
            $values[] = $searchTerm;
        }

        $whereClause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

        $sql = "
            SELECT s.id, s.subtotal_amount, s.discount_rate, s.discount_amount,
                   s.tax_rate, s.tax_amount, s.business_date, s.cash_received, s.cash_balance,
                   s.sales_cycle_id, s.opening_cash_balance,
                   s.total_amount, s.payment_method, s.status, s.created_at,
                   u.username as cashier_name, c.name as customer_name,
                   COALESCE((SELECT SUM(sr.refund_amount) FROM sale_returns sr WHERE sr.original_sale_id = s.id AND sr.status = 'completed'), 0) AS returned_amount,
                   COALESCE(SUM(si.quantity), 0) as item_count
            FROM sales s
            LEFT JOIN users u ON s.cashier_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            LEFT JOIN sale_items si ON si.sale_id = s.id
            $whereClause
            GROUP BY s.id, s.subtotal_amount, s.discount_rate, s.discount_amount,
                     s.tax_rate, s.tax_amount, s.business_date, s.cash_received, s.cash_balance,
                     s.sales_cycle_id, s.opening_cash_balance,
                     s.total_amount, s.payment_method, s.status, s.created_at, u.username, c.name
            ORDER BY s.id DESC
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        $sales = $stmt->fetchAll();

        sendJson($sales);
    } catch (PDOException $e) {
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($method === 'POST' && !$id) {
    try {
        ensureSalesColumns();
        ensureCreditAccountTables();
        ensureSaleReturnTables();
        
        $cashier_id = (int)$user['id'];
        if (isset($inputData['cashier_id']) && (int)$inputData['cashier_id'] !== $cashier_id) {
            sendJson(['error' => 'Sales must be recorded under the signed-in user.'], 403);
        }
        $customer_id = !empty($inputData['customer_id']) ? (int)$inputData['customer_id'] : null;
        $items = isset($inputData['items']) ? $inputData['items'] : [];
        $payment_method = !empty($inputData['payment_method']) ? $inputData['payment_method'] : 'Cash';
        $discount_rate = isset($inputData['discount_rate']) ? (float)$inputData['discount_rate'] : 0;
        $business_date = !empty($inputData['business_date']) ? $inputData['business_date'] : null;
        $cash_received = isset($inputData['cash_received']) && $inputData['cash_received'] !== null ? (float)$inputData['cash_received'] : null;
        $cash_balance = isset($inputData['cash_balance']) && $inputData['cash_balance'] !== null ? (float)$inputData['cash_balance'] : null;
        $sales_cycle_id = !empty($inputData['sales_cycle_id']) ? $inputData['sales_cycle_id'] : null;
        $opening_cash_balance = isset($inputData['opening_cash_balance']) && $inputData['opening_cash_balance'] !== null ? (float)$inputData['opening_cash_balance'] : null;
        $original_sale_id = !empty($inputData['original_sale_id']) ? (int)$inputData['original_sale_id'] : null;
        $transaction_type = $original_sale_id ? 'exchange' : 'sale';

        $validPaymentMethods = ['Cash', 'Card', 'Wallet', 'Bank Transfer', 'Credit'];
        if (!in_array($payment_method, $validPaymentMethods)) {
            $payment_method = 'Cash';
        }

        if (!$cashier_id || empty($items)) {
            sendJson(["error" => "Invalid sale data"], 400);
        }

        ensureSalesCyclesTable();
        $pdo->beginTransaction();
        if ($user['role'] !== 'admin' || $sales_cycle_id) {
            $cycle = $pdo->prepare("SELECT opening_balance FROM sales_cycles WHERE cycle_id = ? AND cashier_id = ? AND status = 'open' FOR UPDATE");
            $cycle->execute([$sales_cycle_id, $cashier_id]);
            $activeCycle = $cycle->fetch();
            if (!$activeCycle) throw new Exception('Open your own sales cycle before recording a sale.');
            $opening_cash_balance = (float)$activeCycle['opening_balance'];
        }

        $subtotalAmount = 0;
        foreach ($items as $item) {
            $quantity = isset($item['quantity']) ? (float)$item['quantity'] : 0;
            if ($quantity <= 0) {
                throw new Exception("Sale items need a positive quantity");
            }

            $stmt = $pdo->prepare('SELECT price, stock_quantity FROM products WHERE id = ? FOR UPDATE');
            $stmt->execute([$item['product_id']]);
            $product = $stmt->fetch();
            
            if (!$product) {
                throw new Exception("Product {$item['product_id']} not found");
            }
            if ((float)$product['stock_quantity'] < $quantity) {
                throw new Exception("Insufficient stock for product ID {$item['product_id']}");
            }
            $subtotalAmount += (float)$product['price'] * $quantity;
        }

        $normalizedDiscountRate = min(100, max(0, $discount_rate));
        $discountAmount = $subtotalAmount * ($normalizedDiscountRate / 100);
        
        $normalizedTaxRate = 0;
        $taxAmount = 0;
        $totalAmount = max(0, $subtotalAmount - $discountAmount);

        $customerCredit = null;
        if ($payment_method === 'Credit') {
            if (!$customer_id) {
                throw new Exception('Select a customer before using Credit payment');
            }

            $stmt = $pdo->prepare('
                SELECT id, name, status, credit_limit, outstanding_balance
                FROM customers
                WHERE id = ?
                FOR UPDATE
            ');
            $stmt->execute([$customer_id]);
            $customerCredit = $stmt->fetch();

            if (!$customerCredit) {
                throw new Exception('Selected customer was not found');
            }
            if (strtolower((string)$customerCredit['status']) !== 'active') {
                throw new Exception('Credit is available only for active customers');
            }

            $creditLimit = (float)$customerCredit['credit_limit'];
            $outstandingBalance = (float)$customerCredit['outstanding_balance'];
            $availableCredit = max(0, $creditLimit - $outstandingBalance);

            if ($creditLimit <= 0) {
                throw new Exception('This customer does not have an approved credit limit');
            }
            if ($totalAmount > $availableCredit + 0.001) {
                throw new Exception('Insufficient customer credit. Available credit is Rs. ' . number_format($availableCredit, 2));
            }
        }

        $stmt = $pdo->prepare("
            INSERT INTO sales
            (cashier_id, customer_id, subtotal_amount, discount_rate, discount_amount,
             tax_rate, tax_amount, business_date, total_amount, payment_method, status,
             cash_received, cash_balance, sales_cycle_id, opening_cash_balance, original_sale_id, transaction_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $cashier_id, $customer_id, $subtotalAmount, $normalizedDiscountRate, $discountAmount,
            $normalizedTaxRate, $taxAmount, $business_date, $totalAmount, $payment_method, 'completed',
            $cash_received, $cash_balance, $sales_cycle_id, $opening_cash_balance, $original_sale_id, $transaction_type
        ]);
        $saleId = $pdo->lastInsertId();

        if ($original_sale_id) {
            $stmt = $pdo->prepare("UPDATE sale_returns SET replacement_sale_id = ? WHERE original_sale_id = ? AND transaction_type = 'exchange' AND replacement_sale_id IS NULL ORDER BY id DESC LIMIT 1");
            $stmt->execute([$saleId, $original_sale_id]);
        }

        if ($customer_id) {
            if ($payment_method === 'Credit') {
                $stmt = $pdo->prepare('
                    UPDATE customers
                    SET total_purchases = total_purchases + ?,
                        outstanding_balance = outstanding_balance + ?
                    WHERE id = ?
                ');
                $stmt->execute([$totalAmount, $totalAmount, $customer_id]);
                $newOutstandingBalance = (float)$customerCredit['outstanding_balance'] + $totalAmount;
                addCreditLedgerEntry(
                    $customer_id,
                    'credit_sale',
                    $totalAmount,
                    0,
                    $newOutstandingBalance,
                    $saleId,
                    null,
                    "INV-{$saleId}",
                    'Credit sale posted to customer account',
                    $cashier_id
                );
            } else {
                $stmt = $pdo->prepare('UPDATE customers SET total_purchases = total_purchases + ? WHERE id = ?');
                $stmt->execute([$totalAmount, $customer_id]);
            }
        }

        foreach ($items as $item) {
            $quantity = isset($item['quantity']) ? (float)$item['quantity'] : 0;
            $stmt = $pdo->prepare('SELECT price, stock_quantity FROM products WHERE id = ? FOR UPDATE');
            $stmt->execute([$item['product_id']]);
            $product = $stmt->fetch();
            
            $price_at_time = $product['price'];
            $stockBefore = (float)$product['stock_quantity'];
            $stockAfter = $stockBefore - $quantity;

            if ($quantity <= 0 || $stockAfter < 0) {
                throw new Exception("Insufficient stock for product ID {$item['product_id']}");
            }

            $stmt = $pdo->prepare('INSERT INTO sale_items (sale_id, product_id, quantity, price_at_time) VALUES (?, ?, ?, ?)');
            $stmt->execute([$saleId, $item['product_id'], $quantity, $price_at_time]);

            $stmt = $pdo->prepare('UPDATE products SET stock_quantity = ? WHERE id = ?');
            $stmt->execute([$stockAfter, $item['product_id']]);

            $stmt = $pdo->prepare("
                INSERT INTO inventory_movements
                (product_id, movement_type, quantity_change, stock_before, stock_after, unit_price, reference_no, notes, created_by)
                VALUES (?, 'sale', ?, ?, ?, ?, ?, 'Stock deducted by POS sale', ?)
            ");
            $stmt->execute([
                $item['product_id'], -$quantity, $stockBefore, $stockAfter, $price_at_time, "SALE-{$saleId}", $cashier_id
            ]);
        }

        $pdo->commit();

        sendJson([
            "message" => "Sale completed successfully",
            "saleId" => $saleId,
            "subtotal_amount" => $subtotalAmount,
            "discount_amount" => $discountAmount,
            "tax_amount" => $taxAmount,
            "total_amount" => $totalAmount,
            "payment_method" => $payment_method,
            "status" => "completed",
            "customer_credit" => $payment_method === 'Credit' ? [
                "customer_id" => $customer_id,
                "credit_limit" => (float)$customerCredit['credit_limit'],
                "outstanding_balance" => (float)$customerCredit['outstanding_balance'] + $totalAmount,
                "available_credit" => max(0, (float)$customerCredit['credit_limit'] - (float)$customerCredit['outstanding_balance'] - $totalAmount)
            ] : null
        ], 201);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        sendJson(["error" => $e->getMessage()], 400);
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($id === 'cycles') {
    if ($method === 'GET') {
        try {
            ensureSalesCyclesTable();
            ensureSalesColumns();

            // The cashier workspace must get its active cycle from the database,
            // not from browser-local state. Scope this lookup to the signed-in user.
            if (isset($_GET['active']) && $_GET['active'] === '1') {
                $stmt = $pdo->prepare("
                    SELECT cycle_id, cashier_id, opened_at, opened_date, opening_balance,
                           closing_balance, closed_at, status
                    FROM sales_cycles
                    WHERE cashier_id = ? AND status = 'open'
                    ORDER BY opened_at ASC
                    LIMIT 1
                ");
                $stmt->execute([(int)$user['id']]);
                $activeCycle = $stmt->fetch();
                sendJson($activeCycle ?: null);
            }
            
            $dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : null;
            $dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : null;
            $cashier = isset($_GET['cashier']) ? $_GET['cashier'] : null;
            $status = isset($_GET['status']) ? $_GET['status'] : null;

            $where = [];
            $values = [];

            if ($dateFrom) {
                $where[] = 'sc.opened_date >= ?';
                $values[] = $dateFrom;
            }
            if ($dateTo) {
                $where[] = 'sc.opened_date <= ?';
                $values[] = $dateTo;
            }
            if ($cashier && $cashier !== 'All Cashiers') {
                $where[] = 'u.username = ?';
                $values[] = $cashier;
            }
            if ($status && $status !== 'All Status') {
                $where[] = 'sc.status = ?';
                $values[] = strtolower($status);
            }

            $whereClause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

            $sql = "
                SELECT
                    sc.cycle_id, sc.cashier_id,
                    COALESCE(u.username, CONCAT('Cashier #', sc.cashier_id)) AS cashier_name,
                    sc.opened_date, sc.opened_at, sc.closed_at, sc.status,
                    sc.opening_balance, sc.closing_balance,
                    COALESCE(s.invoice_count, 0) AS invoice_count,
                    COALESCE(s.item_count, 0) AS item_count,
                    COALESCE(s.total_sales, 0) AS total_sales,
                    COALESCE(s.cash_sales, 0) AS cash_sales,
                    COALESCE(s.card_sales, 0) AS card_sales,
                    COALESCE(s.bank_sales, 0) AS bank_sales,
                    COALESCE(s.discount_total, 0) AS discount_total,
                    COALESCE(s.tax_total, 0) AS tax_total,
                    (sc.opening_balance + COALESCE(s.cash_sales, 0)) AS expected_cash,
                    CASE
                        WHEN sc.closing_balance IS NULL THEN NULL
                        ELSE sc.closing_balance - (sc.opening_balance + COALESCE(s.cash_sales, 0))
                    END AS cash_difference
                FROM sales_cycles sc
                LEFT JOIN users u ON u.id = sc.cashier_id
                LEFT JOIN (
                    SELECT
                        s.sales_cycle_id,
                        COUNT(DISTINCT s.id) AS invoice_count,
                        COALESCE(SUM(CASE WHEN s.status NOT IN ('cancelled', 'voided') THEN s.total_amount ELSE 0 END), 0) AS total_sales,
                        COALESCE(SUM(CASE WHEN s.payment_method = 'Cash' AND s.status NOT IN ('cancelled', 'voided') THEN s.total_amount ELSE 0 END), 0) AS cash_sales,
                        COALESCE(SUM(CASE WHEN s.payment_method = 'Card' AND s.status NOT IN ('cancelled', 'voided') THEN s.total_amount ELSE 0 END), 0) AS card_sales,
                        COALESCE(SUM(CASE WHEN s.payment_method = 'Bank Transfer' AND s.status NOT IN ('cancelled', 'voided') THEN s.total_amount ELSE 0 END), 0) AS bank_sales,
                        COALESCE(SUM(CASE WHEN s.status NOT IN ('cancelled', 'voided') THEN s.discount_amount ELSE 0 END), 0) AS discount_total,
                        COALESCE(SUM(CASE WHEN s.status NOT IN ('cancelled', 'voided') THEN s.tax_amount ELSE 0 END), 0) AS tax_total,
                        COALESCE(SUM(CASE WHEN s.status NOT IN ('cancelled', 'voided') THEN items.item_count ELSE 0 END), 0) AS item_count
                    FROM sales s
                    LEFT JOIN (
                        SELECT sale_id, SUM(quantity) AS item_count
                        FROM sale_items
                        GROUP BY sale_id
                    ) items ON items.sale_id = s.id
                    WHERE s.sales_cycle_id IS NOT NULL
                      AND (s.status IS NULL OR s.status != 'refunded')
                    GROUP BY s.sales_cycle_id
                ) s ON s.sales_cycle_id = sc.cycle_id
                $whereClause
                ORDER BY sc.opened_at DESC
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($values);
            $cycles = $stmt->fetchAll();

            sendJson($cycles);
        } catch (PDOException $e) {
            sendJson(["error" => "Internal server error", "details" => $e->getMessage()], 500);
        }
    }

    if ($method === 'POST') {
        $lockAcquired = false;
        try {
            ensureSalesCyclesTable();
            $cycle_id = isset($inputData['cycle_id']) ? $inputData['cycle_id'] : null;
            $cashier_id = (int)$user['id'];
            $opened_at = isset($inputData['opened_at']) ? $inputData['opened_at'] : null;
            $opened_date = isset($inputData['opened_date']) ? $inputData['opened_date'] : null;
            $opening_balance = isset($inputData['opening_balance']) ? (float)$inputData['opening_balance'] : null;

            if (!$cycle_id || !$cashier_id || !$opened_at || !$opened_date || $opening_balance === null || $opening_balance < 0) {
                sendJson(["error" => "Invalid sales cycle data"], 400);
            }

            // Serialize opens for this cashier so simultaneous browsers cannot
            // both pass the existence check and create duplicate open cycles.
            $lockName = 'sales-cycle-cashier-' . $cashier_id;
            $stmt = $pdo->prepare("SELECT GET_LOCK(?, 10)");
            $stmt->execute([$lockName]);
            $lockAcquired = (int)$stmt->fetchColumn() === 1;
            if (!$lockAcquired) {
                sendJson(["error" => "Unable to lock cashier sales cycle. Please try again."], 409);
            }

            $stmt = $pdo->prepare("
                SELECT cycle_id, cashier_id, opened_at, opened_date, opening_balance,
                       closing_balance, closed_at, status
                FROM sales_cycles
                WHERE cashier_id = ? AND status = 'open'
                ORDER BY opened_at ASC
                LIMIT 1
            ");
            $stmt->execute([$cashier_id]);
            $existingCycle = $stmt->fetch();
            if ($existingCycle) {
                $pdo->prepare("SELECT RELEASE_LOCK(?)")->execute([$lockName]);
                $lockAcquired = false;
                sendJson(["message" => "Existing sales cycle resumed", "resumed" => true, "cycle" => $existingCycle]);
            }

            $stmt = $pdo->prepare("
                INSERT INTO sales_cycles (cycle_id, cashier_id, opened_at, opened_date, opening_balance, status)
                VALUES (?, ?, ?, ?, ?, 'open')
            ");
            $stmt->execute([$cycle_id, $cashier_id, $opened_at, $opened_date, $opening_balance]);

            $pdo->prepare("SELECT RELEASE_LOCK(?)")->execute([$lockName]);
            $lockAcquired = false;

            sendJson(["message" => "Sales cycle opened", "cycle_id" => $cycle_id]);
        } catch (PDOException $e) {
            if ($lockAcquired) {
                $pdo->prepare("SELECT RELEASE_LOCK(?)")->execute([$lockName]);
            }
            sendJson(["error" => "Internal server error", "details" => $e->getMessage()], 500);
        }
    }

    // Since next.js uses PATCH for closing, we use PATCH here too (PHP handles it via $method)
    if ($method === 'PATCH') {
        try {
            ensureSalesCyclesTable();
            $cycle_id = isset($inputData['cycle_id']) ? $inputData['cycle_id'] : null;
            $adminClose = !empty($inputData['admin_close']);
            $cashier_id = isset($inputData['cashier_id']) ? $inputData['cashier_id'] : null;
            $opened_at = isset($inputData['opened_at']) ? $inputData['opened_at'] : null;
            $opened_date = isset($inputData['opened_date']) ? $inputData['opened_date'] : null;
            $opening_balance = isset($inputData['opening_balance']) ? (float)$inputData['opening_balance'] : 0;
            $closing_balance = isset($inputData['closing_balance']) ? (float)$inputData['closing_balance'] : null;
            $closed_at = isset($inputData['closed_at']) ? $inputData['closed_at'] : null;

            if (!$cycle_id || $closing_balance === null || $closing_balance < 0) {
                sendJson(["error" => "Invalid closing balance"], 400);
            }

            if ($adminClose && $user['role'] !== 'admin') {
                sendJson(["error" => "Only an administrator can force-close a sales cycle"], 403);
            }

            $stmt = $pdo->prepare("SELECT cashier_id, status FROM sales_cycles WHERE cycle_id = ? LIMIT 1");
            $stmt->execute([$cycle_id]);
            $cycleRecord = $stmt->fetch();
            if (!$cycleRecord) {
                sendJson(["error" => "Sales cycle not found"], 404);
            }
            if ($cycleRecord['status'] !== 'open') {
                sendJson(["error" => "This sales cycle is already closed"], 409);
            }
            if (!$adminClose && (int)$cycleRecord['cashier_id'] !== (int)$user['id']) {
                sendJson(["error" => "You can close only your own active sales cycle"], 403);
            }

            $stmt = $pdo->prepare("
                SELECT
                    COUNT(*) AS invoice_count,
                    COALESCE(SUM(total_amount), 0) AS total_sales,
                    COALESCE(SUM(CASE WHEN payment_method = 'Cash' THEN total_amount ELSE 0 END), 0) AS cash_sales,
                    COALESCE(SUM(CASE WHEN payment_method = 'Card' THEN total_amount ELSE 0 END), 0) AS card_sales,
                    COALESCE(SUM(CASE WHEN payment_method = 'Bank Transfer' THEN total_amount ELSE 0 END), 0) AS bank_sales
                FROM sales
                WHERE sales_cycle_id = ?
            ");
            $stmt->execute([$cycle_id]);
            $summary = $stmt->fetch();

            $stmt = $pdo->prepare("
                UPDATE sales_cycles
                SET closing_balance = ?, closed_at = ?, status = 'closed'
                WHERE cycle_id = ? AND status = 'open'
            ");
            $closedAtDate = $closed_at ? $closed_at : date('Y-m-d H:i:s');
            $stmt->execute([$closing_balance, $closedAtDate, $cycle_id]);

            if ($stmt->rowCount() === 0) {
                sendJson(["error" => "This sales cycle was already closed"], 409);
            }

            sendJson([
                "message" => "Sales cycle closed",
                "cycle_id" => $cycle_id,
                "summary" => $summary
            ]);
        } catch (PDOException $e) {
            sendJson(["error" => "Internal server error", "details" => $e->getMessage()], 500);
        }
    }
}

if ($method === 'GET' && $id === 'items') {
    try {
        ensureSalesColumns();

        $date = isset($_GET['date']) && $_GET['date'] !== '' ? $_GET['date'] : date('Y-m-d');

        $stmt = $pdo->prepare("
            SELECT
                si.product_id,
                COALESCE(p.name, CONCAT('Product #', si.product_id)) AS product_name,
                p.sku,
                p.category,
                p.unit,
                p.product_type,
                SUM(si.quantity) AS quantity,
                SUM(si.quantity * si.price_at_time) AS total_amount,
                COUNT(DISTINCT s.id) AS invoice_count
            FROM sale_items si
            JOIN sales s ON s.id = si.sale_id
            LEFT JOIN products p ON p.id = si.product_id
            WHERE COALESCE(s.business_date, DATE(s.created_at)) = ?
              AND (s.status IS NULL OR (s.status != 'refunded' AND s.status != 'cancelled' AND s.status != 'voided'))
            GROUP BY si.product_id, p.name, p.sku, p.category, p.unit, p.product_type
            ORDER BY quantity DESC, total_amount DESC, product_name ASC
        ");
        $stmt->execute([$date]);
        $items = $stmt->fetchAll();

        $summary = [
            "date" => $date,
            "product_count" => count($items),
            "quantity" => 0,
            "total_amount" => 0,
            "invoice_count" => 0
        ];

        foreach ($items as $item) {
            $summary["quantity"] += (float)$item["quantity"];
            $summary["total_amount"] += (float)$item["total_amount"];
        }

        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT id) AS invoice_count
            FROM sales
            WHERE COALESCE(business_date, DATE(created_at)) = ?
        ");
        $stmt->execute([$date]);
        $row = $stmt->fetch();
        $summary["invoice_count"] = (int)($row["invoice_count"] ?? 0);

        sendJson([
            "summary" => $summary,
            "items" => $items
        ]);
    } catch (PDOException $e) {
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($method === 'GET' && $id) {
    try {
        ensureSalesColumns();
        ensureSaleReturnTables();

        $stmt = $pdo->prepare("
            SELECT s.id, s.subtotal_amount, s.discount_rate, s.discount_amount,
                   s.tax_rate, s.tax_amount, s.business_date, s.cash_received, s.cash_balance,
                   s.sales_cycle_id, s.opening_cash_balance,
                   s.total_amount, s.payment_method, s.status, s.created_at,
                   u.username as cashier_name, c.name as customer_name
            FROM sales s
            LEFT JOIN users u ON s.cashier_id = u.id
            LEFT JOIN customers c ON s.customer_id = c.id
            WHERE s.id = ?
            LIMIT 1
        ");
        $stmt->execute([$id]);
        $sale = $stmt->fetch();

        if (!$sale) {
            sendJson(["error" => "Sale not found"], 404);
        }

        sendJson([
            "sale" => $sale,
            "items" => detailedSaleItems($id)
        ]);
    } catch (PDOException $e) {
        sendJson(["error" => "Internal server error"], 500);
    }
}

if ($method === 'PATCH' && $id) {
    try {
        ensureSalesColumns();
        ensureRevocationAuditTable();
        ensureCreditAccountTables();

        $action = isset($inputData['action']) ? $inputData['action'] : null;
        if ($action !== 'cancel') {
            sendJson(["error" => "Unsupported sales action"], 400);
        }
        $reason = isset($inputData['reason']) ? trim($inputData['reason']) : '';
        if ($reason === '') {
            sendJson(["error" => "Reason is required"], 400);
        }
        $approver = null;

        $pdo->beginTransaction();

        $stmt = $pdo->prepare('SELECT * FROM sales WHERE id = ? FOR UPDATE');
        $stmt->execute([$id]);
        $sale = $stmt->fetch();

        if (!$sale) {
            $pdo->rollBack();
            sendJson(["error" => "Sale not found"], 404);
        }

        if ($user['role'] !== 'admin') {
            if ((int)$sale['cashier_id'] !== (int)$user['id']) throw new Exception('Cashiers can cancel only their own invoices');
            if (empty($sale['sales_cycle_id']) || $sale['sales_cycle_id'] !== ($inputData['sales_cycle_id'] ?? '')) throw new Exception('Cashiers can cancel only invoices from their active sales cycle');
        }

        if (in_array($sale['status'], ['refunded', 'voided', 'cancelled'])) {
            $pdo->rollBack();
            sendJson(["message" => "Invoice is already reversed"]);
        }

        $items = saleItems($id);
        foreach ($items as $item) {
            $stmt = $pdo->prepare('SELECT stock_quantity FROM products WHERE id = ? FOR UPDATE');
            $stmt->execute([$item['product_id']]);
            $product = $stmt->fetch();

            if (!$product) {
                throw new Exception("Product {$item['product_id']} not found");
            }

            $stockBefore = (float)$product['stock_quantity'];
            $quantity = (float)$item['quantity'];
            $stockAfter = $stockBefore + $quantity;

            $stmt = $pdo->prepare('UPDATE products SET stock_quantity = ? WHERE id = ?');
            $stmt->execute([$stockAfter, $item['product_id']]);

            $stmt = $pdo->prepare("
                INSERT INTO inventory_movements
                (product_id, movement_type, quantity_change, stock_before, stock_after, unit_price, reference_no, notes, created_by)
                VALUES (?, 'adjustment', ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $item['product_id'],
                $quantity,
                $stockBefore,
                $stockAfter,
                $item['price_at_time'],
                "CANCEL-{$id}",
                'Cancelled bill stock restoration',
                $user['id']
            ]);
        }

        if (!empty($sale['customer_id'])) {
            if ($sale['payment_method'] === 'Credit') {
                $allocatedAmount = activeCreditAllocationsForSale($id);
                if ($allocatedAmount > 0.001) {
                    throw new Exception('Reverse the customer payment allocation before cancelling this credit invoice');
                }
                $customerStmt = $pdo->prepare('SELECT outstanding_balance FROM customers WHERE id = ? FOR UPDATE');
                $customerStmt->execute([$sale['customer_id']]);
                $customerBalance = (float)$customerStmt->fetchColumn();
                $nextCustomerBalance = max(0, $customerBalance - (float)$sale['total_amount']);
                $stmt = $pdo->prepare('
                    UPDATE customers
                    SET total_purchases = GREATEST(0, total_purchases - ?),
                        outstanding_balance = GREATEST(0, outstanding_balance - ?)
                    WHERE id = ?
                ');
                $stmt->execute([(float)$sale['total_amount'], (float)$sale['total_amount'], $sale['customer_id']]);
                addCreditLedgerEntry(
                    $sale['customer_id'],
                    'credit_sale_cancel',
                    0,
                    (float)$sale['total_amount'],
                    $nextCustomerBalance,
                    $id,
                    null,
                    "CANCEL-{$id}",
                    'Credit invoice cancelled',
                    $user['id']
                );
            } else {
                $stmt = $pdo->prepare('UPDATE customers SET total_purchases = GREATEST(0, total_purchases - ?) WHERE id = ?');
                $stmt->execute([(float)$sale['total_amount'], $sale['customer_id']]);
            }
        }

        $nextStatus = 'cancelled';
        $stmt = $pdo->prepare("UPDATE sales SET status = ? WHERE id = ?");
        $stmt->execute([$nextStatus, $id]);

        recordRevocation(
            $id,
            'completed_sale_cancelled',
            $user['id'],
            null,
            $reason,
            (float)$sale['total_amount'],
            [
                "previous_status" => $sale['status'],
                "next_status" => $nextStatus,
                "payment_method" => $sale['payment_method'],
                "sales_cycle_id" => $sale['sales_cycle_id']
            ]
        );

        $pdo->commit();
        sendJson(["message" => "Invoice cancelled; stock and balances were restored"]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        sendJson(["error" => $e->getMessage()], 400);
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        sendJson(["error" => "Internal server error"], 500);
    }
}

sendJson(["error" => "Endpoint not found"], 404);
?>
